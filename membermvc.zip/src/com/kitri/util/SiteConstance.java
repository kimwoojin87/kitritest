package com.kitri.util;

public class SiteConstance {
	public static final String ENCODE = "utf-8";
//	DB정보 셋팅
	public static final String DB_DRIVER = "oracle.jdbc.driver.OracleDriver";
	public static final String DB_URL = "jdbc:oracle:thin:@localhost:1521:orcl";
	public static final String DB_USERNAME = "sb";
	public static final String DB_PASSWORD = "1234";
	
}
